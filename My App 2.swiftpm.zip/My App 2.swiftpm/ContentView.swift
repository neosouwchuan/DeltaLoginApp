import SwiftUI
import CoreImage.CIFilterBuiltins
public var imin =  false
struct qrview:View {
    private var changethis : String = ""
    @State private var secretmessage : String = "fuckoff"
    
    var body: some View {
        VStack{
            Text(verbatim: "Generated QR code").font(.largeTitle)
            let myuiimage = generateQR(from: secretmessage)
            Image(uiImage: myuiimage).resizable().scaledToFit().frame(width:200,height:200)
        }.onAppear(perform: {
            secretmessage = gencode()
            print(secretmessage)
        })
    }
}
struct FirstView: View {
    @State public var digit: String = ""
    
    let defaults = UserDefaults.standard

    var body: some View {
            
            VStack {
                
                Image("Deltaupscale")
                    .resizable()
                    .imageScale(.small)
                    .scaledToFit()
                    .foregroundColor(.accentColor)
                Text("BIBO")
                    .font(.largeTitle)
                TextField("Insert 4D",text:$digit).onSubmit {
                    print("hi")
                }.padding(20)
                NavigationLink("Submit", destination: SecondView().onAppear(perform: {
                    
                    defaults.set(String(digit),forKey:"username")
                    defaults.set(Date.now,forKey: "datein")
                }))
                
                
            }
        
    }
}
func generateQR (from secretmessage: String) -> UIImage{
    let context = CIContext()
    let filter = CIFilter.qrCodeGenerator()
    filter.message = Data(secretmessage.utf8)
    if var outputImage = filter.outputImage{
        outputImage = outputImage.transformed(by: CGAffineTransform(scaleX: 5, y: 5))
        if let cgimg = context.createCGImage(outputImage, from: outputImage.extent){
            return UIImage(cgImage: cgimg)
        }
    }
    return UIImage(systemName: "xmark.circle") ?? UIImage()
}
func gencode () -> String{
    var temp : String = (UserDefaults.standard.string(forKey: "username") ?? "")
    let currdate = UserDefaults.standard.object(forKey: "datein")
    let outformat = DateFormatter()
    outformat.dateFormat = "MMddyyyy"
    var dt = outformat.string(from: currdate as! Date)
    dt = String(dt.prefix(4)) + String(dt.suffix(2))
    print(dt)
    let dayoutformat = DateFormatter()
    dayoutformat.dateFormat="HHmmss"
    var currsec : Int64 = 0
    var currtime = dayoutformat.string(from: (Date()))
    
    
    print(String(currsec))
    let code = temp + dt + String(currtime)
    print(code)
    var encoded : String = ""
    var running : Int = Int(0)
    var tempnonop : String = ""
    var newtemp : Int = 0
    for chr in code{
        //encoded += String((running + Int(temp)) % 10)
        temp = String(chr)
        //print(temp + "amongus")
        newtemp = (Int(temp) ?? 0) + running
        //print(newtemp)
        newtemp = (newtemp) % Int(10)
        
        tempnonop = String(Int(newtemp))
        encoded += String(tempnonop)
        
        running += (Int(temp) ?? 0)
        
    }
    return encoded
}
func getDocumentsDirectory() -> URL{
    let paths = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
    return paths[0]
}
struct SecondView: View {
    
    let defaults = UserDefaults.standard
    //@State private var presenta:String = ""
    
    //var digit : String = UserDefaults.standard.string(forKey: "username") ?? ""
    var body: some View {
        @State var filenameimage = "Deltaupscale"
        NavigationView{
            VStack {
                //print(String(digit.dynamicType))
                //defaults.string(forKey: "username")?
                //var digit : String = UserDefaults.standard.string(forKey: "username") ?? ""
                //var presenta = "4D"+digit
                Image(filenameimage)
                    .resizable()
                
                    .imageScale(.small)
                    .scaledToFit()
                    .foregroundColor(.accentColor)
                Text("4D" + (UserDefaults.standard.string(forKey: "username") ?? "")).font(.largeTitle)
                NavigationLink("Gen QR", destination: qrview() ).padding(20).font(.largeTitle).onAppear(perform: {
                
                
                 })
            
            }.navigationBarBackButtonHidden(true)
        }.navigationViewStyle(StackNavigationViewStyle()).navigationBarBackButtonHidden(true)
    }
}
struct ContentView:View{
    let defaults = UserDefaults.standard
    @State public var digit: String = ""
    
    var body: some View{
        NavigationView{
            
            if defaults.object(forKey: "username") != nil{
                SecondView().navigationTitle("Loggedin")    
            }
            else{
                FirstView().navigationTitle("Login")
            }
        }.navigationViewStyle(StackNavigationViewStyle())
            
    }
    
}
